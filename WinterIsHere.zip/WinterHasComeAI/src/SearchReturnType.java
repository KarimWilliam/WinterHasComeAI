
public class SearchReturnType {
	SearchTreeNode ResSTN;
	int Expansion;
	
	SearchReturnType(SearchTreeNode ResSTN, int Expansion){
		this.ResSTN=ResSTN;
		this.Expansion=Expansion;
	}
}
