import java.util.Arrays;
import java.util.LinkedList;

public class GenericSearchProcedure {

	GenericSearchProblem Problem;
	Object SearchStrategy;
	

	GenericSearchProcedure(GenericSearchProblem Problem, Object SearchStrategy){
		this.Problem=Problem;
		this.SearchStrategy=SearchStrategy;
		
	}
}
